package com.portfoliogayol.grg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrgApplicationTests {

	@Test
	void contextLoads() {
	}

}
